"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import {
  doc,
  getDoc,
  updateDoc,
  arrayUnion,
  arrayRemove,
  collection,
  addDoc,
  serverTimestamp,
  getDocs,
  query,
  where,
  orderBy,
} from "firebase/firestore"
import { db } from "@/lib/firebase/config"
import { useAuth } from "@/lib/auth-context"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { StarRating } from "@/components/star-rating"
import { Heart, MessageSquare, ShoppingCart, User } from 'lucide-react'
import { ProductImage } from "@/components/ui/product-image"
import { cn, formatPrice } from "@/lib/utils"

interface Review {
  id: string
  productId: string
  userId: string
  userName: string | null
  userPhotoURL: string | null
  rating: number
  text: string
  createdAt: string
}

interface Product {
  id: string
  title: string
  description: string
  price: number
  images: string[]
  category: string
  condition: string
  sellerName: string
  status: string
  sellerId: string
  inStockQuantity: number
}

interface ChatData {
  id: string
  participants: string[]
  productId: string
  productTitle: string
  productImage: string
  createdAt: any
  lastMessage: string | null
  lastMessageTime: any | null
}

type FirestoreData = {
  participants: string[]
  productId: string
  productTitle: string
  productImage: string
  createdAt: any
  lastMessage: string | null
  lastMessageTime: any | null
}

export default function ProductPage() {
  const { id } = useParams()
  const router = useRouter()
  const { user, userRole } = useAuth()
  const { toast } = useToast()

  const [product, setProduct] = useState<Product | null>(null)
  const [seller, setSeller] = useState<any | null>(null)
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [inWishlist, setInWishlist] = useState(false)
  const [reviewText, setReviewText] = useState("")
  const [rating, setRating] = useState(0)
  const [submittingReview, setSubmittingReview] = useState(false)
  const [selectedImage, setSelectedImage] = useState(0)

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        const productDoc = await getDoc(doc(db, "products", id as string))

        if (productDoc.exists()) {
          const productData = { id: productDoc.id, ...productDoc.data() } as Product
          setProduct(productData)

          // Fetch seller data
          const sellerDoc = await getDoc(doc(db, "users", productData.sellerId))
          if (sellerDoc.exists()) {
            setSeller(sellerDoc.data())
          }

          // Fetch reviews
          const reviewsQuery = query(
            collection(db, "reviews"),
            where("productId", "==", id),
            orderBy("createdAt", "desc"),
          )
          const reviewsSnapshot = await getDocs(reviewsQuery)
          const reviewsData = reviewsSnapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })) as Review[]
          setReviews(reviewsData)

          // Check if in user's wishlist
          if (user) {
            const userDoc = await getDoc(doc(db, "users", user.uid))
            if (userDoc.exists() && userDoc.data().wishlist) {
              setInWishlist(userDoc.data().wishlist.includes(id))
            }
          }
        } else {
          toast({
            title: "Product not found",
            description: "The product you are looking for does not exist",
            variant: "destructive",
          })
          router.push("/products")
        }
      } catch (error) {
        console.error("Error fetching product:", error)
        toast({
          title: "Error",
          description: "Failed to load product details",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchProductData()
  }, [id, user, router, toast])

  const toggleWishlist = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to add items to your wishlist",
        variant: "destructive",
      })
      router.push("/login")
      return
    }

    try {
      const userRef = doc(db, "users", user.uid)

      if (inWishlist) {
        await updateDoc(userRef, {
          wishlist: arrayRemove(id),
        })
        setInWishlist(false)
        toast({
          title: "Removed from wishlist",
          description: `${product?.title} has been removed from your wishlist`,
        })
      } else {
        await updateDoc(userRef, {
          wishlist: arrayUnion(id),
        })
        setInWishlist(true)
        toast({
          title: "Added to wishlist",
          description: `${product?.title} has been added to your wishlist`,
        })
      }
    } catch (error) {
      console.error("Error updating wishlist:", error)
      toast({
        title: "Error",
        description: "Failed to update wishlist",
        variant: "destructive",
      })
    }
  }

  const startChat = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to contact the seller",
        variant: "destructive",
      })
      router.push("/login")
      return
    }

    if (!product) return

    try {
      // Check if chat already exists
      const chatsQuery = query(collection(db, "chats"), where("participants", "array-contains", user.uid))
      const chatsSnapshot = await getDocs(chatsQuery)

      let existingChat: ChatData | null = null
      for (const doc of chatsSnapshot.docs) {
        const data = doc.data() as FirestoreData
        if (data.participants.includes(product.sellerId)) {
          existingChat = {
            id: doc.id,
            ...data
          } as ChatData
          break
        }
      }

      if (existingChat) {
        router.push(`/messages/${existingChat.id}`)
      } else {
        // Create new chat
        const chatData: Omit<ChatData, 'id'> = {
          participants: [user.uid, product.sellerId],
          productId: product.id,
          productTitle: product.title,
          productImage: product.images[selectedImage] || "/placeholder.svg",
          createdAt: serverTimestamp(),
          lastMessage: null,
          lastMessageTime: null,
        }
        const chatRef = await addDoc(collection(db, "chats"), chatData)
        router.push(`/messages/${chatRef.id}`)
      }
    } catch (error) {
      console.error("Error starting chat:", error)
      toast({
        title: "Error",
        description: "Failed to start chat with seller",
        variant: "destructive",
      })
    }
  }

  const submitReview = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to leave a review",
        variant: "destructive",
      })
      router.push("/login")
      return
    }

    if (rating === 0) {
      toast({
        title: "Rating required",
        description: "Please select a star rating",
        variant: "destructive",
      })
      return
    }

    setSubmittingReview(true)

    try {
      const reviewData = {
        productId: id,
        userId: user.uid,
        userName: user.displayName,
        userPhotoURL: user.photoURL,
        rating,
        text: reviewText,
        createdAt: serverTimestamp(),
      }

      await addDoc(collection(db, "reviews"), reviewData)

      // Add review to state
      setReviews([
        {
          id: "temp-id",
          ...reviewData,
          createdAt: new Date().toISOString(),
        } as Review,
        ...reviews,
      ])

      // Reset form
      setReviewText("")
      setRating(0)

      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      })
    } catch (error) {
      console.error("Error submitting review:", error)
      toast({
        title: "Error",
        description: "Failed to submit review",
        variant: "destructive",
      })
    } finally {
      setSubmittingReview(false)
    }
  }

  const handleAddToCart = () => {
    if (!product) return
    
    // Create cart item data
    const cartItem = {
      productId: product.id,
      title: product.title,
      price: product.price,
      image: product.images[selectedImage] || "/placeholder.svg",
      quantity: 1,
      maxQuantity: product.inStockQuantity,
      sellerId: product.sellerId
    }

    // Store in sessionStorage temporarily
    sessionStorage.setItem('cartItem', JSON.stringify(cartItem))
    
    // Redirect to cart page
    router.push('/cart')
  }

  if (loading) {
    return (
      <div className="container py-12">
        <div className="flex items-center justify-center">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container py-12">
        <div className="text-center">
          <h1 className="text-2xl font-bold">Product not found</h1>
          <p className="mt-2">The product you are looking for does not exist or has been removed.</p>
          <Button asChild className="mt-4">
            <Link href="/products">Browse Products</Link>
          </Button>
        </div>
      </div>
    )
  }

  const averageRating =
    reviews.length > 0 ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length : 0

  return (
    <div className="container py-12">
      <div className="grid gap-8 md:grid-cols-2">
        {/* Product Images */}
        <div className="space-y-4">
          <ProductImage
            src={product.images[selectedImage] || "/placeholder.svg"}
            alt={product.title}
            className="aspect-square w-full"
            priority
          />
          {product.images.length > 1 && (
            <div className="grid grid-cols-4 gap-4">
              {product.images.map((image: string, index: number) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={cn(
                    "relative aspect-square overflow-hidden rounded-lg",
                    selectedImage === index && "ring-2 ring-primary"
                  )}
                >
                  <ProductImage
                    src={image}
                    alt={`${product.title} - Image ${index + 1}`}
                    className="h-full w-full"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">{product.title}</h1>
            <p className="mt-2 text-2xl font-semibold text-primary">
              {formatPrice(product.price)}
            </p>
          </div>

          <div className="flex items-center gap-4">
            <Badge variant="outline">{product.category}</Badge>
            <Badge variant="outline">{product.condition}</Badge>
            <Badge variant={product.status === "approved" ? "default" : "secondary"}>
              {product.status}
            </Badge>
          </div>

          <div>
            <h2 className="text-lg font-semibold">Description</h2>
            <p className="mt-2 text-muted-foreground">{product.description}</p>
          </div>

          <div>
            <h2 className="text-lg font-semibold">Seller</h2>
            <p className="mt-2 text-muted-foreground">{product.sellerName}</p>
          </div>

          {user && user.uid !== product.sellerId && (
            <Button className="w-full" onClick={startChat}>
              <MessageSquare className="mr-2 h-4 w-4" />
              Contact Seller
            </Button>
          )}
        </div>
      </div>

      <div className="mt-8 md:mt-12">
        <Tabs defaultValue="reviews">
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="reviews" className="flex-1 sm:flex-initial">
              Reviews ({reviews.length})
            </TabsTrigger>
            <TabsTrigger value="shipping" className="flex-1 sm:flex-initial">
              Shipping & Returns
            </TabsTrigger>
          </TabsList>
          <TabsContent value="reviews" className="pt-6">
            {user && (
              <Card className="mb-6">
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2">Write a Review</h3>
                  <div className="mb-4">
                    <StarRating value={rating} onChange={setRating} />
                  </div>
                  <Textarea
                    placeholder="Share your experience with this product..."
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                    className="mb-4"
                  />
                  <Button onClick={submitReview} disabled={submittingReview}>
                    {submittingReview ? "Submitting..." : "Submit Review"}
                  </Button>
                </CardContent>
              </Card>
            )}

            {reviews.length === 0 ? (
              <div className="text-center py-12">
                <h3 className="text-lg font-medium">No reviews yet</h3>
                <p className="text-muted-foreground">Be the first to review this product</p>
              </div>
            ) : (
              <div className="space-y-6">
                {reviews.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={review.userPhotoURL || ""} alt={review.userName || "User"} />
                            <AvatarFallback>{review.userName?.[0] || "U"}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{review.userName}</p>
                            <p className="text-xs text-muted-foreground">
                              {review.createdAt ? new Date(review.createdAt).toLocaleDateString() : "Recently"}
                            </p>
                          </div>
                        </div>
                        <StarRating value={review.rating} readOnly size="sm" />
                      </div>
                      <p className="mt-4">{review.text}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          <TabsContent value="shipping" className="pt-6">
            <Card>
              <CardContent className="p-4 space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Shipping</h3>
                  <p>
                    Shipping methods and costs are determined by the seller. Please contact the seller for more
                    information.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Returns</h3>
                  <p>
                    Return policies are determined by the seller. Please contact the seller for more information about
                    their return policy.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Buyer Protection</h3>
                  <p>
                    Our marketplace offers buyer protection for eligible purchases. If you don't receive your item or
                    it's significantly different from the description, you may be eligible for a refund.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}