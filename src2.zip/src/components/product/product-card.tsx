import Link from "next/link"
import { useState } from "react"
import { ProductImage } from "@/components/ui/product-image"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatPrice } from "@/lib/utils"
import { Heart, ShoppingCart, Share2, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/lib/auth-context"
import { doc, updateDoc, arrayUnion, arrayRemove } from "firebase/firestore"
import { db } from "@/lib/firebase/config"

interface ProductCardProps {
  id: string
  title: string
  description: string
  price: number
  images: string[]
  category: string
  condition: string
  sellerName: string
  status: string
  sellerId: string
  inStockQuantity: number
}

export function ProductCard({
  id,
  title,
  description,
  price,
  images,
  category,
  condition,
  sellerName,
  status,
  sellerId,
  inStockQuantity,
}: ProductCardProps) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isWishlisted, setIsWishlisted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const toggleWishlist = async (e: React.MouseEvent) => {
    e.preventDefault() // Prevent navigation when clicking the button
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to add items to your wishlist",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const userRef = doc(db, "users", user.uid)
      if (isWishlisted) {
        await updateDoc(userRef, {
          wishlist: arrayRemove(id),
        })
        setIsWishlisted(false)
        toast({
          title: "Removed from wishlist",
          description: `${title} has been removed from your wishlist`,
        })
      } else {
        await updateDoc(userRef, {
          wishlist: arrayUnion(id),
        })
        setIsWishlisted(true)
        toast({
          title: "Added to wishlist",
          description: `${title} has been added to your wishlist`,
        })
      }
    } catch (error) {
      console.error("Error updating wishlist:", error)
      toast({
        title: "Error",
        description: "Failed to update wishlist",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const addToCart = (e: React.MouseEvent) => {
    e.preventDefault() // Prevent navigation when clicking the button
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please login to add items to your cart",
        variant: "destructive",
      })
      return
    }

    // Create cart item data
    const cartItem = {
      productId: id,
      title,
      price,
      image: images[0] || "/placeholder.svg",
      quantity: 1,
      maxQuantity: inStockQuantity,
      sellerId
    }

    // Store in sessionStorage temporarily
    sessionStorage.setItem('cartItem', JSON.stringify(cartItem))
    
    toast({
      title: "Added to cart",
      description: `${title} has been added to your cart`,
    })
  }

  const shareProduct = (e: React.MouseEvent) => {
    e.preventDefault() // Prevent navigation when clicking the button
    if (navigator.share) {
      navigator.share({
        title,
        text: description,
        url: window.location.origin + `/products/${id}`,
      })
    } else {
      // Fallback for browsers that don't support Web Share API
      navigator.clipboard.writeText(window.location.origin + `/products/${id}`)
      toast({
        title: "Link copied",
        description: "Product link has been copied to clipboard",
      })
    }
  }

  return (
    <Link href={`/products/${id}`}>
      <Card className="group h-full overflow-hidden transition-all hover:shadow-lg">
        <CardHeader className="p-0">
          <div className="relative">
            <ProductImage
              src={images[0] || "/placeholder.svg"}
              alt={title}
              className="aspect-square w-full transition-transform duration-300 group-hover:scale-105"
              priority
            />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity group-hover:opacity-100">
              <div className="flex gap-2">
                <Button
                  size="icon"
                  variant="secondary"
                  className="rounded-full"
                  onClick={toggleWishlist}
                  disabled={isLoading}
                >
                  <Heart className={`h-4 w-4 ${isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
                </Button>
                <Button
                  size="icon"
                  variant="secondary"
                  className="rounded-full"
                  onClick={addToCart}
                >
                  <ShoppingCart className="h-4 w-4" />
                </Button>
                <Button
                  size="icon"
                  variant="secondary"
                  className="rounded-full"
                  onClick={shareProduct}
                >
                  <Share2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
            {inStockQuantity <= 0 && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                <Badge variant="destructive" className="text-lg">
                  Out of Stock
                </Badge>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="line-clamp-1 font-semibold">{title}</h3>
              <p className="text-sm text-muted-foreground">{sellerName}</p>
            </div>
            <Badge variant={status === "approved" ? "default" : "secondary"}>
              {status}
            </Badge>
          </div>
          <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
            {description}
          </p>
        </CardContent>
        <CardFooter className="flex items-center justify-between p-4 pt-0">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-background/50 backdrop-blur">
              {category}
            </Badge>
            <Badge variant="outline" className="bg-background/50 backdrop-blur">
              {condition}
            </Badge>
          </div>
          <p className="font-semibold text-primary">{formatPrice(price)}</p>
        </CardFooter>
      </Card>
    </Link>
  )
} 