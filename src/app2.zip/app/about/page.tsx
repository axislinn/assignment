import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, Users, Recycle, Heart } from "lucide-react"

export const metadata: Metadata = {
  title: "About Us | SecondChance Marketplace",
  description: "Learn about SecondChance Marketplace, our mission, values, and the team behind the platform",
}

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <section className="mb-12 text-center">
        <h1 className="mb-4 text-4xl font-bold md:text-5xl">About SecondChance</h1>
        <p className="mx-auto mb-6 max-w-3xl text-lg text-muted-foreground">
          We're on a mission to create a sustainable marketplace where pre-loved items find new homes, reducing waste
          and creating value for everyone.
        </p>
      </section>

      {/* Our Story */}
      <section className="mb-16">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          <div className="flex flex-col justify-center">
            <h2 className="mb-4 text-3xl font-bold">Our Story</h2>
            <p className="mb-4 text-muted-foreground">
              SecondChance was founded in 2023 with a simple idea: to make it easy for people to buy and sell pre-loved
              items, giving these items a second chance at life while helping people save money and reduce waste.
            </p>
            <p className="mb-4 text-muted-foreground">
              What started as a small community of environmentally conscious individuals has grown into a thriving
              marketplace with thousands of users across the country. Our platform connects buyers and sellers directly,
              creating a more sustainable and personal shopping experience.
            </p>
            <p className="text-muted-foreground">
              Today, we continue to grow and innovate, always staying true to our core mission of sustainability,
              community, and value.
            </p>
          </div>
          <div className="flex items-center justify-center">
            <div className="overflow-hidden rounded-lg bg-muted">
              <img
                src="/placeholder.svg?height=400&width=600"
                alt="SecondChance team"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="mb-16">
        <h2 className="mb-8 text-center text-3xl font-bold">Our Values</h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardContent className="flex flex-col items-center p-6 text-center">
              <Recycle className="mb-4 h-12 w-12 text-primary" />
              <h3 className="mb-2 text-xl font-bold">Sustainability</h3>
              <p className="text-muted-foreground">
                We're committed to reducing waste by giving items a second life instead of ending up in landfills.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex flex-col items-center p-6 text-center">
              <Users className="mb-4 h-12 w-12 text-primary" />
              <h3 className="mb-2 text-xl font-bold">Community</h3>
              <p className="text-muted-foreground">
                We foster a supportive community where buyers and sellers connect directly and build relationships.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex flex-col items-center p-6 text-center">
              <CheckCircle className="mb-4 h-12 w-12 text-primary" />
              <h3 className="mb-2 text-xl font-bold">Quality</h3>
              <p className="text-muted-foreground">
                We encourage honest descriptions and fair pricing to ensure a positive experience for everyone.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex flex-col items-center p-6 text-center">
              <Heart className="mb-4 h-12 w-12 text-primary" />
              <h3 className="mb-2 text-xl font-bold">Accessibility</h3>
              <p className="text-muted-foreground">
                We believe everyone should have access to affordable, quality items regardless of their budget.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Our Team */}
      <section className="mb-16">
        <h2 className="mb-8 text-center text-3xl font-bold">Meet Our Team</h2>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {[
            { name: "Alex Johnson", role: "Founder & CEO", image: "/placeholder.svg?height=300&width=300" },
            { name: "Sam Taylor", role: "CTO", image: "/placeholder.svg?height=300&width=300" },
            { name: "Jordan Lee", role: "Head of Operations", image: "/placeholder.svg?height=300&width=300" },
            { name: "Casey Morgan", role: "Customer Success", image: "/placeholder.svg?height=300&width=300" },
          ].map((member, index) => (
            <Card key={index}>
              <CardContent className="p-6 text-center">
                <div className="mx-auto mb-4 h-32 w-32 overflow-hidden rounded-full">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <h3 className="mb-1 text-xl font-bold">{member.name}</h3>
                <p className="text-muted-foreground">{member.role}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Join Us */}
      <section className="rounded-xl bg-muted p-8 text-center">
        <h2 className="mb-4 text-3xl font-bold">Join Our Community</h2>
        <p className="mx-auto mb-6 max-w-2xl text-muted-foreground">
          Whether you're looking to declutter your home, find unique items, or just save money while helping the planet,
          SecondChance is the place for you.
        </p>
        <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link href="/auth/register">
            <Button size="lg">Sign Up Now</Button>
          </Link>
          <Link href="/contact">
            <Button size="lg" variant="outline">
              Contact Us
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
