"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"
import ProductGrid from "@/components/product-grid"
import CategoryList from "@/components/category-list"
import { useAuth } from "@/lib/auth-context"

export default function Home() {
  const { user, userRole } = useAuth()
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setIsSearching(true)
      window.location.href = `/products?search=${encodeURIComponent(searchQuery)}`
    }
  }

  // Check if user is a seller or admin (they don't need to see the "Become a seller" section)
  const isSellerOrAdmin = userRole === "seller" || userRole === "admin"

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Hero Section */}
      <section className="mb-12 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-700 p-8 text-white">
        <div className="mx-auto max-w-4xl text-center">
          <h1 className="mb-4 text-4xl font-bold md:text-5xl">Buy and Sell Second-Hand Items with Ease</h1>
          <p className="mb-6 text-lg">
            Join our community of buyers and sellers to find great deals or give your items a second chance.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link href="/products">
              <Button size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
                Browse Products
              </Button>
            </Link>
            {!user ? (
              <Link href="/auth/register">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  Sign Up Now
                </Button>
              </Link>
            ) : (
              <Link href={userRole === "seller" ? "/seller/listings/new" : "/wishlist"}>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  {userRole === "seller" ? "Add Listing" : "View Wishlist"}
                </Button>
              </Link>
            )}
          </div>
        </div>
      </section>

      {/* Search Bar */}
      <div className="mb-12 rounded-lg border bg-card p-4 shadow-sm">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search for products..."
            className="w-full rounded-md border-input bg-background px-10 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Button type="submit" className="absolute right-1 top-1" disabled={isSearching}>
            {isSearching ? "Searching..." : "Search"}
          </Button>
        </form>
      </div>

      {/* Categories */}
      <section className="mb-12">
        <h2 className="mb-6 text-2xl font-bold">Browse Categories</h2>
        <CategoryList />
      </section>

      {/* Featured Products */}
      <section className="mb-12">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold">Featured Products</h2>
          <Link href="/products" className="text-blue-600 hover:underline">
            View All
          </Link>
        </div>
        <ProductGrid featured={true} limit={8} />
      </section>

      {/* Recent Products */}
      <section className="mb-12">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold">Recently Added</h2>
          <Link href="/products" className="text-blue-600 hover:underline">
            View All
          </Link>
        </div>
        <ProductGrid limit={8} />
      </section>

      {/* Become a Seller - Only show if user is not already a seller or admin */}
      {!isSellerOrAdmin && (
        <section className="mb-12 rounded-xl bg-gray-100 p-8 dark:bg-gray-800">
          <div className="mx-auto max-w-4xl text-center">
            <h2 className="mb-4 text-3xl font-bold">Become a Seller Today</h2>
            <p className="mb-6 text-lg">
              Turn your unused items into cash. Create a seller account and start listing your products in minutes.
            </p>
            <Link href={user ? "/account/upgrade" : "/auth/register?type=seller"}>
              <Button size="lg">Start Selling</Button>
            </Link>
          </div>
        </section>
      )}
    </div>
  )
}
