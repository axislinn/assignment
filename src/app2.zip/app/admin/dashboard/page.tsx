"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { BarChart, LineChart, Package, ShoppingCart, Users } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { getAdminStats } from "@/lib/firebase/admin"

export default function AdminDashboard() {
  const { user, userRole } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is logged in and is an admin
    if (!user) {
      router.push("/auth/login")
      return
    }

    if (userRole !== "admin") {
      toast({
        title: "Access denied",
        description: "You need admin privileges to access this page",
        variant: "destructive",
      })
      router.push("/")
      return
    }

    const fetchStats = async () => {
      try {
        const adminStats = await getAdminStats()
        setStats(adminStats)
      } catch (error) {
        console.error("Error fetching admin stats:", error)
        toast({
          title: "Error",
          description: "Failed to load admin statistics",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [user, userRole, router, toast])

  // Fallback stats if none are found
  const fallbackStats = {
    totalUsers: 120,
    totalBuyers: 95,
    totalSellers: 25,
    pendingSellers: 5,
    totalProducts: 250,
    pendingProducts: 15,
    totalSales: 180,
    totalRevenue: 8750.5,
    recentUsers: [
      { id: "1", name: "John Doe", email: "john@example.com", role: "buyer", date: "2023-05-15" },
      { id: "2", name: "Jane Smith", email: "jane@example.com", role: "seller", date: "2023-05-12" },
      { id: "3", name: "Bob Johnson", email: "bob@example.com", role: "buyer", date: "2023-05-10" },
    ],
    pendingApprovals: [
      { id: "1", type: "seller", name: "Alice Brown", email: "alice@example.com", date: "2023-05-14" },
      { id: "2", type: "product", title: "Vintage Watch", seller: "Jane Smith", date: "2023-05-13" },
      { id: "3", type: "seller", name: "Charlie Davis", email: "charlie@example.com", date: "2023-05-11" },
    ],
  }

  const displayStats = stats || fallbackStats

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Admin Dashboard</h1>

      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="flex flex-row items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Users</p>
              <p className="text-2xl font-bold">{displayStats.totalUsers}</p>
            </div>
            <Users className="h-8 w-8 text-primary" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-row items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Products</p>
              <p className="text-2xl font-bold">{displayStats.totalProducts}</p>
            </div>
            <Package className="h-8 w-8 text-green-500" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-row items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Sales</p>
              <p className="text-2xl font-bold">{displayStats.totalSales}</p>
            </div>
            <ShoppingCart className="h-8 w-8 text-blue-500" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-row items-center justify-between p-6">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
              <p className="text-2xl font-bold">${displayStats.totalRevenue.toFixed(2)}</p>
            </div>
            <LineChart className="h-8 w-8 text-yellow-500" />
          </CardContent>
        </Card>
      </div>

      <div className="mb-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Pending Approvals</CardTitle>
            <CardDescription>Items requiring your attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {displayStats.pendingApprovals.map((item: any) => (
                <div key={item.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{item.type === "seller" ? item.name : item.title}</p>
                    <p className="text-sm text-muted-foreground">
                      {item.type === "seller" ? `Seller: ${item.email}` : `Seller: ${item.seller}`}
                    </p>
                  </div>
                  <Button size="sm">Approve</Button>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Link href={`/admin/${displayStats.pendingSellers > displayStats.pendingProducts ? "users" : "listings"}`}>
              <Button variant="outline" size="sm">
                View All Pending
              </Button>
            </Link>
          </CardFooter>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Recent Users</CardTitle>
            <CardDescription>Newly registered users</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {displayStats.recentUsers.map((user: any) => (
                <div key={user.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{user.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {user.email} • {user.role}
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground">{new Date(user.date).toLocaleDateString()}</p>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/admin/users">
              <Button variant="outline" size="sm">
                View All Users
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="mb-8">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="sales">Sales</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle>Platform Overview</CardTitle>
              <CardDescription>Key metrics for your marketplace</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full bg-muted/30 flex items-center justify-center">
                <BarChart className="h-16 w-16 text-muted-foreground" />
                <p className="ml-2 text-muted-foreground">Platform metrics visualization would appear here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>User Growth</CardTitle>
              <CardDescription>New user registrations over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full bg-muted/30 flex items-center justify-center">
                <LineChart className="h-16 w-16 text-muted-foreground" />
                <p className="ml-2 text-muted-foreground">User growth chart would appear here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="products">
          <Card>
            <CardHeader>
              <CardTitle>Product Listings</CardTitle>
              <CardDescription>Product listing trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full bg-muted/30 flex items-center justify-center">
                <Package className="h-16 w-16 text-muted-foreground" />
                <p className="ml-2 text-muted-foreground">Product listing chart would appear here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="sales">
          <Card>
            <CardHeader>
              <CardTitle>Sales Analytics</CardTitle>
              <CardDescription>Sales and revenue over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full bg-muted/30 flex items-center justify-center">
                <ShoppingCart className="h-16 w-16 text-muted-foreground" />
                <p className="ml-2 text-muted-foreground">Sales analytics chart would appear here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Link href="/admin/users">
          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <CardTitle>Manage Users</CardTitle>
              <CardDescription>
                {displayStats.totalUsers} users ({displayStats.pendingSellers} pending approval)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Users className="h-12 w-12 text-primary" />
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/listings">
          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <CardTitle>Manage Listings</CardTitle>
              <CardDescription>
                {displayStats.totalProducts} products ({displayStats.pendingProducts} pending approval)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Package className="h-12 w-12 text-green-500" />
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/settings">
          <Card className="transition-all hover:shadow-md">
            <CardHeader>
              <CardTitle>Platform Settings</CardTitle>
              <CardDescription>Configure marketplace settings</CardDescription>
            </CardHeader>
            <CardContent>
              <LineChart className="h-12 w-12 text-blue-500" />
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  )
}
