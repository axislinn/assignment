"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/components/ui/use-toast"
import { Heart, MessageSquare, Share2, Star } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { getProduct } from "@/lib/firebase/products"
import { toggleWishlist } from "@/lib/firebase/wishlist"
import { createChat } from "@/lib/firebase/messages"
import ProductGrid from "@/components/product-grid"

export default function ProductPage() {
  const { id } = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const { toast } = useToast()
  const [product, setProduct] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [selectedImage, setSelectedImage] = useState(0)

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const fetchedProduct = await getProduct(id as string, user?.uid)
        setProduct(fetchedProduct)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching product:", error)
        toast({
          title: "Error",
          description: "Failed to load product details",
          variant: "destructive",
        })
        router.push("/products")
      }
    }

    if (id) {
      fetchProduct()
    }
  }, [id, user?.uid, router, toast])

  const handleWishlist = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to add items to your wishlist",
        variant: "destructive",
      })
      return
    }

    try {
      await toggleWishlist(user.uid, id as string)
      setProduct({
        ...product,
        isWishlisted: !product.isWishlisted,
      })

      toast({
        title: "Success",
        description: "Wishlist updated successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update wishlist",
        variant: "destructive",
      })
    }
  }

  const handleContact = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to contact the seller",
        variant: "destructive",
      })
      return
    }

    if (!product.seller) {
      toast({
        title: "Error",
        description: "Seller information not available",
        variant: "destructive",
      })
      return
    }

    try {
      // Check if there's an existing chat or create a new one
      const chatId = await createChat([user.uid, product.seller.id], {
        text: `Hi, I'm interested in your product: ${product.title}`,
        senderId: user.uid,
      })

      router.push(`/messages?chat=${chatId}`)
    } catch (error) {
      console.error("Error creating chat:", error)
      toast({
        title: "Error",
        description: "Failed to start conversation with seller",
        variant: "destructive",
      })
    }
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: product.title,
          text: product.description,
          url: window.location.href,
        })
        .catch((error) => {
          console.error("Error sharing:", error)
          copyToClipboard()
        })
    } else {
      copyToClipboard()
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard
      .writeText(window.location.href)
      .then(() => {
        toast({
          title: "Link copied",
          description: "Product link copied to clipboard",
        })
      })
      .catch((err) => {
        console.error("Failed to copy:", err)
        toast({
          title: "Error",
          description: "Failed to copy link to clipboard",
          variant: "destructive",
        })
      })
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          <div>
            <Skeleton className="aspect-square w-full rounded-lg" />
            <div className="mt-4 flex gap-2">
              {[1, 2, 3, 4].map((_, index) => (
                <Skeleton key={index} className="h-20 w-20 rounded-md" />
              ))}
            </div>
          </div>
          <div className="space-y-4">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <div className="flex gap-2 pt-4">
              <Skeleton className="h-10 w-32" />
              <Skeleton className="h-10 w-32" />
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <h2 className="text-xl font-semibold">Product not found</h2>
            <p className="text-muted-foreground">The product you are looking for does not exist or has been removed.</p>
            <Button className="mt-4" onClick={() => router.push("/products")}>
              Browse Products
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        <div>
          <div className="overflow-hidden rounded-lg bg-muted">
            <img
              src={product.images?.[selectedImage] || "/placeholder.svg?height=600&width=600"}
              alt={product.title || "Product image"}
              className="h-full w-full object-contain"
              style={{ maxHeight: "500px" }}
            />
          </div>
          <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
            {(product.images || []).map((image: string, index: number) => (
              <button
                key={index}
                className={`overflow-hidden rounded-md border ${selectedImage === index ? "ring-2 ring-primary" : ""}`}
                onClick={() => setSelectedImage(index)}
              >
                <img
                  src={image || "/placeholder.svg?height=100&width=100"}
                  alt={`${product.title || "Product"} thumbnail ${index + 1}`}
                  className="h-20 w-20 object-cover"
                />
              </button>
            ))}
          </div>
        </div>

        <div>
          <div className="mb-6">
            <div className="mb-2 flex items-center justify-between">
              <h1 className="text-3xl font-bold">{product.title || "Untitled Product"}</h1>
              <Button variant="ghost" size="icon" onClick={handleShare}>
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
            <div className="mb-4 flex items-center gap-2">
              <Badge variant="outline" className="capitalize">
                {product.condition || "Used"}
              </Badge>
              {product.featured && <Badge>Featured</Badge>}
            </div>
            <p className="mb-4 text-2xl font-bold text-primary">${(product.price || 0).toFixed(2)}</p>
            <p className="text-muted-foreground">{product.description || "No description available"}</p>
          </div>

          <Separator className="my-6" />

          <div className="mb-6">
            <h3 className="mb-2 text-lg font-medium">Seller Information</h3>
            <div className="flex items-center gap-4">
              <Avatar>
                <AvatarImage src={product.seller?.photoURL} />
                <AvatarFallback>{product.seller?.displayName?.charAt(0) || "S"}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{product.seller?.displayName || "Unknown Seller"}</p>
                <div className="flex items-center text-sm text-muted-foreground">
                  <Star className="mr-1 h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span>{product.seller?.rating || 0} Rating</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button className="flex-1" onClick={handleContact}>
              <MessageSquare className="mr-2 h-4 w-4" /> Contact Seller
            </Button>
            <Button variant="outline" className="flex-1" onClick={handleWishlist}>
              <Heart className={`mr-2 h-4 w-4 ${product.isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
              {product.isWishlisted ? "Saved" : "Save"}
            </Button>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Product Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Category</p>
                  <p>{product.category || "Uncategorized"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Condition</p>
                  <p className="capitalize">{product.condition || "Used"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Location</p>
                  <p>{product.location || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Listed</p>
                  <p>{new Date(product.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="mt-12">
        <Tabs defaultValue="similar">
          <TabsList className="mb-6">
            <TabsTrigger value="similar">Similar Products</TabsTrigger>
            <TabsTrigger value="seller">More from this Seller</TabsTrigger>
          </TabsList>
          <TabsContent value="similar">
            <ProductGrid category={product.category} limit={4} userId={user?.uid} />
          </TabsContent>
          <TabsContent value="seller">
            <ProductGrid sellerId={product.sellerId} limit={4} userId={user?.uid} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
