import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Terms of Service | SecondChance Marketplace",
  description: "Read the terms and conditions for using SecondChance Marketplace",
}

export default function TermsPage() {
  const lastUpdated = "January 15, 2023"

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="mb-4 text-4xl font-bold">Terms of Service</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">
          Please read these Terms of Service carefully before using the SecondChance Marketplace website and services.
        </p>
        <p className="mt-2 text-sm text-muted-foreground">Last Updated: {lastUpdated}</p>
      </div>

      <Tabs defaultValue="overview" className="mb-12">
        <TabsList className="mb-8 flex w-full flex-wrap justify-center gap-2">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="account">Account Terms</TabsTrigger>
          <TabsTrigger value="marketplace">Marketplace Rules</TabsTrigger>
          <TabsTrigger value="content">Content Policy</TabsTrigger>
          <TabsTrigger value="liability">Liability</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Terms of Service Overview</h2>
              <p className="mb-4 text-muted-foreground">
                These Terms of Service ("Terms") govern your access to and use of the SecondChance Marketplace website,
                services, and applications (collectively, the "Services"). By accessing or using our Services, you agree
                to be bound by these Terms. If you do not agree to these Terms, you may not access or use the Services.
              </p>
              <p className="mb-4 text-muted-foreground">
                SecondChance Marketplace ("we", "us", or "our") is an online platform that allows users to buy and sell
                second-hand items. We do not own, sell, or control any of the items listed by users on our platform. We
                merely facilitate the connection between buyers and sellers.
              </p>
              <p className="mb-4 text-muted-foreground">
                We reserve the right to modify these Terms at any time. If we make changes, we will provide notice by
                posting the updated Terms on our website and updating the "Last Updated" date. Your continued use of the
                Services after any such changes constitutes your acceptance of the new Terms.
              </p>
              <p className="text-muted-foreground">
                If you have any questions about these Terms, please contact us at legal@secondchance.com.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Account Terms</h2>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Account Creation and Eligibility</h3>
                <p className="mb-2 text-muted-foreground">
                  To use certain features of our Services, you must create an account. When you create an account, you
                  agree to:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Provide accurate, current, and complete information</li>
                  <li>Maintain and promptly update your account information</li>
                  <li>Keep your password secure and confidential</li>
                  <li>Notify us immediately of any unauthorized use of your account</li>
                </ul>
                <p className="mt-2 text-muted-foreground">
                  You must be at least 18 years old to create an account. By creating an account, you represent and
                  warrant that you are at least 18 years old.
                </p>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Account Types</h3>
                <p className="mb-2 text-muted-foreground">We offer two types of accounts:</p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>
                    <strong>Buyer Account:</strong> Allows you to browse listings, make purchases, and communicate with
                    sellers.
                  </li>
                  <li>
                    <strong>Seller Account:</strong> Includes all buyer features plus the ability to list items for
                    sale. Seller accounts may require additional verification and approval.
                  </li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Account Termination</h3>
                <p className="mb-2 text-muted-foreground">
                  We reserve the right to suspend or terminate your account at any time for any reason, including but
                  not limited to:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Violation of these Terms</li>
                  <li>Engaging in fraudulent or illegal activities</li>
                  <li>Creating multiple accounts</li>
                  <li>Providing false information</li>
                  <li>Inactivity for an extended period</li>
                </ul>
                <p className="mt-2 text-muted-foreground">
                  You may also delete your account at any time through your account settings. However, certain
                  information may be retained as required by law or for legitimate business purposes.
                </p>
              </div>

              <div>
                <h3 className="mb-2 text-xl font-bold">Account Security</h3>
                <p className="text-muted-foreground">
                  You are responsible for all activity that occurs under your account. If you suspect any unauthorized
                  use of your account, you must notify us immediately. We are not responsible for any loss or damage
                  resulting from unauthorized use of your account.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="marketplace">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Marketplace Rules</h2>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Listing Items</h3>
                <p className="mb-2 text-muted-foreground">When listing items for sale on our platform, you agree to:</p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Provide accurate and detailed descriptions of the items</li>
                  <li>Disclose any defects, damages, or issues with the items</li>
                  <li>Set reasonable and transparent prices</li>
                  <li>Include clear photos that accurately represent the items</li>
                  <li>Only list items that you legally own and have the right to sell</li>
                  <li>Comply with all applicable laws and regulations</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Prohibited Items</h3>
                <p className="mb-2 text-muted-foreground">
                  The following items are prohibited from being listed or sold on our platform:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Illegal items or substances</li>
                  <li>Counterfeit or replica items</li>
                  <li>Stolen property</li>
                  <li>Hazardous materials</li>
                  <li>Weapons and explosives</li>
                  <li>Adult content or services</li>
                  <li>Personal information or data</li>
                  <li>Items that infringe on intellectual property rights</li>
                  <li>Live animals</li>
                  <li>Human remains or body parts</li>
                  <li>Any other items prohibited by law</li>
                </ul>
                <p className="mt-2 text-muted-foreground">
                  We reserve the right to remove any listing that violates these prohibitions or that we determine, in
                  our sole discretion, is inappropriate for our platform.
                </p>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Transactions</h3>
                <p className="mb-2 text-muted-foreground">When engaging in transactions on our platform:</p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Buyers agree to pay the listed price plus any applicable shipping and handling fees</li>
                  <li>Sellers agree to ship items promptly after receiving payment</li>
                  <li>All transactions must be completed through our platform's payment system</li>
                  <li>Attempts to circumvent our payment system are prohibited</li>
                  <li>We may collect fees on transactions as outlined in our Fee Schedule</li>
                </ul>
              </div>

              <div>
                <h3 className="mb-2 text-xl font-bold">Dispute Resolution</h3>
                <p className="text-muted-foreground">
                  In the event of a dispute between a buyer and seller, we encourage the parties to communicate directly
                  to resolve the issue. If that is unsuccessful, our platform provides a dispute resolution process. We
                  reserve the right to make final decisions on disputes based on our policies and the evidence provided
                  by both parties.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="content">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Content Policy</h2>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">User Content</h3>
                <p className="mb-2 text-muted-foreground">
                  "User Content" includes any text, images, videos, reviews, messages, or other materials that you post,
                  upload, or otherwise share on our platform. By posting User Content, you grant us a non-exclusive,
                  worldwide, royalty-free license to use, copy, modify, display, and distribute that content in
                  connection with our Services.
                </p>
                <p className="text-muted-foreground">
                  You are solely responsible for all User Content that you post and warrant that:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>You own or have the necessary rights to the User Content</li>
                  <li>The User Content does not infringe on any third party's rights</li>
                  <li>The User Content complies with these Terms and all applicable laws</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Prohibited Content</h3>
                <p className="mb-2 text-muted-foreground">You may not post User Content that:</p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Is illegal, harmful, threatening, abusive, harassing, defamatory, or invasive of privacy</li>
                  <li>Contains hate speech or promotes discrimination</li>
                  <li>Is sexually explicit or pornographic</li>
                  <li>Infringes on intellectual property rights</li>
                  <li>Contains viruses, malware, or other harmful code</li>
                  <li>Impersonates any person or entity</li>
                  <li>Constitutes unauthorized advertising or spam</li>
                  <li>Violates any applicable law or regulation</li>
                </ul>
              </div>

              <div>
                <h3 className="mb-2 text-xl font-bold">Content Moderation</h3>
                <p className="mb-2 text-muted-foreground">
                  We reserve the right, but not the obligation, to monitor, review, and remove any User Content that
                  violates these Terms or that we find objectionable for any reason. We may take these actions without
                  prior notification to you.
                </p>
                <p className="text-muted-foreground">
                  If you encounter content that you believe violates our policies, please report it to us through the
                  reporting tools available on our platform or by contacting support@secondchance.com.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="liability">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Liability and Disclaimers</h2>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Disclaimer of Warranties</h3>
                <p className="mb-2 text-muted-foreground">
                  THE SERVICES ARE PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
                  IMPLIED, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
                  PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT.
                </p>
                <p className="text-muted-foreground">We do not warrant that:</p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>The Services will be uninterrupted or error-free</li>
                  <li>Defects will be corrected</li>
                  <li>
                    The Services or the servers that make them available are free of viruses or other harmful components
                  </li>
                  <li>Information provided by users is accurate, reliable, or complete</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Limitation of Liability</h3>
                <p className="mb-2 text-muted-foreground">
                  TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL SECONDCHANCE MARKETPLACE, ITS
                  AFFILIATES, DIRECTORS, EMPLOYEES, OR AGENTS BE LIABLE FOR ANY INDIRECT, PUNITIVE, INCIDENTAL, SPECIAL,
                  CONSEQUENTIAL, OR EXEMPLARY DAMAGES, INCLUDING WITHOUT LIMITATION DAMAGES FOR LOSS OF PROFITS,
                  GOODWILL, USE, DATA, OR OTHER INTANGIBLE LOSSES, ARISING OUT OF OR RELATING TO THE USE OF, OR
                  INABILITY TO USE, THE SERVICES.
                </p>
                <p className="text-muted-foreground">
                  Our liability is limited to the maximum extent permitted by law. In jurisdictions that do not allow
                  the exclusion or limitation of liability for consequential or incidental damages, our liability shall
                  be limited to the maximum extent permitted by law.
                </p>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Indemnification</h3>
                <p className="text-muted-foreground">
                  You agree to indemnify, defend, and hold harmless SecondChance Marketplace, its affiliates, officers,
                  directors, employees, and agents from and against any and all claims, liabilities, damages, losses,
                  costs, expenses, or fees (including reasonable attorneys' fees) that arise from or relate to:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Your use of the Services</li>
                  <li>Your User Content</li>
                  <li>Your violation of these Terms</li>
                  <li>Your violation of any rights of another person or entity</li>
                </ul>
              </div>

              <div>
                <h3 className="mb-2 text-xl font-bold">Third-Party Links and Services</h3>
                <p className="text-muted-foreground">
                  Our Services may contain links to third-party websites or services that are not owned or controlled by
                  SecondChance Marketplace. We have no control over, and assume no responsibility for, the content,
                  privacy policies, or practices of any third-party websites or services. You acknowledge and agree that
                  we shall not be responsible or liable, directly or indirectly, for any damage or loss caused or
                  alleged to be caused by or in connection with the use of or reliance on any such content, goods, or
                  services available on or through any such websites or services.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8 text-center">
        <h2 className="mb-4 text-2xl font-bold">Questions About Our Terms</h2>
        <p className="mx-auto mb-6 max-w-2xl text-muted-foreground">
          If you have any questions or concerns about our Terms of Service, please contact our Legal Team at
          legal@secondchance.com or write to us at:
        </p>
        <address className="mb-6 not-italic text-muted-foreground">
          SecondChance Marketplace
          <br />
          Attn: Legal Department
          <br />
          123 Market Street
          <br />
          San Francisco, CA 94103
          <br />
          United States
        </address>
        <Link href="/contact">
          <Button>Contact Us</Button>
        </Link>
      </div>
    </div>
  )
}
