import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Privacy Policy | SecondChance Marketplace",
  description: "Learn about how SecondChance Marketplace collects, uses, and protects your personal information",
}

export default function PrivacyPolicyPage() {
  const lastUpdated = "January 15, 2023"

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="mb-4 text-4xl font-bold">Privacy Policy</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">
          This Privacy Policy describes how SecondChance Marketplace ("we", "us", or "our") collects, uses, and shares
          your personal information when you use our website and services.
        </p>
        <p className="mt-2 text-sm text-muted-foreground">Last Updated: {lastUpdated}</p>
      </div>

      <Tabs defaultValue="overview" className="mb-12">
        <TabsList className="mb-8 flex w-full flex-wrap justify-center gap-2">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="collection">Information Collection</TabsTrigger>
          <TabsTrigger value="use">Use of Information</TabsTrigger>
          <TabsTrigger value="sharing">Information Sharing</TabsTrigger>
          <TabsTrigger value="rights">Your Rights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Privacy Policy Overview</h2>
              <p className="mb-4 text-muted-foreground">
                At SecondChance Marketplace, we take your privacy seriously. This Privacy Policy is designed to help you
                understand what information we collect, why we collect it, and how you can update, manage, and delete
                your information.
              </p>
              <p className="mb-4 text-muted-foreground">
                By using our website and services, you agree to the collection and use of information in accordance with
                this policy. We will not use or share your information with anyone except as described in this Privacy
                Policy.
              </p>
              <p className="mb-4 text-muted-foreground">
                We use your data to provide and improve our services. By using our services, you agree to the collection
                and use of information in accordance with this policy.
              </p>
              <p className="text-muted-foreground">
                If you have any questions about this Privacy Policy, please contact us at privacy@secondchance.com.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="collection">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Information We Collect</h2>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Personal Information</h3>
                <p className="mb-2 text-muted-foreground">
                  We may collect the following types of personal information:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Contact information (name, email address, phone number, mailing address)</li>
                  <li>Account information (username, password)</li>
                  <li>Profile information (profile picture, bio)</li>
                  <li>Payment information (credit card details, billing address)</li>
                  <li>Transaction information (purchase history, selling history)</li>
                  <li>Communication information (messages between users, customer support inquiries)</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Automatically Collected Information</h3>
                <p className="mb-2 text-muted-foreground">
                  When you visit our website, we automatically collect certain information about your device and usage,
                  including:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Device information (IP address, browser type, operating system)</li>
                  <li>Usage data (pages visited, time spent on pages, links clicked)</li>
                  <li>Location information (general location based on IP address)</li>
                  <li>Cookies and similar tracking technologies</li>
                </ul>
              </div>

              <div>
                <h3 className="mb-2 text-xl font-bold">Information from Third Parties</h3>
                <p className="text-muted-foreground">
                  We may receive information about you from third parties, such as:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Social media platforms when you connect your account</li>
                  <li>Payment processors for transaction information</li>
                  <li>Identity verification services</li>
                  <li>Marketing and analytics partners</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="use">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">How We Use Your Information</h2>

              <p className="mb-4 text-muted-foreground">
                We use the information we collect for various purposes, including:
              </p>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Providing and Improving Our Services</h3>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Creating and managing your account</li>
                  <li>Processing transactions between buyers and sellers</li>
                  <li>Facilitating communication between users</li>
                  <li>Providing customer support</li>
                  <li>Improving our website and services</li>
                  <li>Developing new features and products</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Communication</h3>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Sending transactional emails (order confirmations, shipping updates)</li>
                  <li>Providing customer service and support</li>
                  <li>Sending marketing communications (if you've opted in)</li>
                  <li>Responding to your inquiries and requests</li>
                  <li>Sending administrative messages about our services</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Security and Fraud Prevention</h3>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Verifying your identity</li>
                  <li>Detecting and preventing fraudulent transactions</li>
                  <li>Protecting against unauthorized access to accounts</li>
                  <li>Ensuring the security of our platform</li>
                </ul>
              </div>

              <div>
                <h3 className="mb-2 text-xl font-bold">Legal Compliance</h3>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Complying with applicable laws and regulations</li>
                  <li>Responding to legal requests and preventing harm</li>
                  <li>Enforcing our terms of service</li>
                  <li>Establishing, exercising, or defending legal claims</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sharing">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Information Sharing and Disclosure</h2>

              <p className="mb-4 text-muted-foreground">
                We may share your information in the following circumstances:
              </p>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">With Other Users</h3>
                <p className="text-muted-foreground">
                  When you use our marketplace, certain information is shared with other users:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Sellers can see buyers' usernames, profile information, and shipping addresses</li>
                  <li>Buyers can see sellers' usernames, profile information, and general location</li>
                  <li>Messages sent through our platform are shared with the recipient</li>
                  <li>Reviews and ratings you leave are visible to other users</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">With Service Providers</h3>
                <p className="text-muted-foreground">
                  We share information with third-party service providers who help us operate our business:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Payment processors to handle transactions</li>
                  <li>Cloud storage providers to store your information</li>
                  <li>Analytics providers to help us understand how our site is used</li>
                  <li>Customer service providers to assist with support inquiries</li>
                  <li>Marketing partners to help us promote our services</li>
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">For Legal Reasons</h3>
                <p className="text-muted-foreground">We may share information when we believe it's necessary to:</p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>Comply with applicable laws and regulations</li>
                  <li>Respond to valid legal process (such as a search warrant or court order)</li>
                  <li>Protect our rights, privacy, safety, or property</li>
                  <li>Protect the rights, privacy, safety, or property of our users or others</li>
                  <li>Detect, prevent, or address fraud and other illegal activity</li>
                </ul>
              </div>

              <div>
                <h3 className="mb-2 text-xl font-bold">Business Transfers</h3>
                <p className="text-muted-foreground">
                  If we are involved in a merger, acquisition, or sale of all or a portion of our assets, your
                  information may be transferred as part of that transaction. We will notify you via email and/or a
                  prominent notice on our website of any change in ownership or uses of your personal information.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rights">
          <Card>
            <CardContent className="p-6">
              <h2 className="mb-4 text-2xl font-bold">Your Rights and Choices</h2>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Account Information</h3>
                <p className="text-muted-foreground">
                  You can access, update, or delete your account information at any time by logging into your account
                  settings. If you cannot access certain information or have questions about the information we have on
                  file about you, please contact us at privacy@secondchance.com.
                </p>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Communication Preferences</h3>
                <p className="text-muted-foreground">
                  You can opt out of receiving promotional emails from us by following the unsubscribe instructions in
                  those emails. Even if you opt out, we may still send you non-promotional communications, such as those
                  about your account or our ongoing business relations.
                </p>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Cookies and Tracking Technologies</h3>
                <p className="text-muted-foreground">
                  Most web browsers are set to accept cookies by default. If you prefer, you can usually choose to set
                  your browser to remove or reject cookies. Please note that if you choose to remove or reject cookies,
                  this could affect certain features of our website.
                </p>
              </div>

              <div className="mb-6">
                <h3 className="mb-2 text-xl font-bold">Do Not Track</h3>
                <p className="text-muted-foreground">
                  Some browsers have a "Do Not Track" feature that lets you tell websites that you do not want to have
                  your online activities tracked. We currently do not respond to "Do Not Track" signals.
                </p>
              </div>

              <div>
                <h3 className="mb-2 text-xl font-bold">Your Privacy Rights</h3>
                <p className="mb-2 text-muted-foreground">
                  Depending on your location, you may have certain rights regarding your personal information,
                  including:
                </p>
                <ul className="ml-6 list-disc space-y-1 text-muted-foreground">
                  <li>The right to access personal information we hold about you</li>
                  <li>The right to request correction of inaccurate personal information</li>
                  <li>The right to request deletion of your personal information</li>
                  <li>The right to object to processing of your personal information</li>
                  <li>The right to data portability</li>
                  <li>The right to withdraw consent</li>
                </ul>
                <p className="mt-2 text-muted-foreground">
                  To exercise these rights, please contact us at privacy@secondchance.com. We will respond to your
                  request within a reasonable timeframe.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-8 text-center">
        <h2 className="mb-4 text-2xl font-bold">Contact Us About Privacy</h2>
        <p className="mx-auto mb-6 max-w-2xl text-muted-foreground">
          If you have any questions or concerns about our Privacy Policy or our data practices, please contact our
          Privacy Team at privacy@secondchance.com or write to us at:
        </p>
        <address className="mb-6 not-italic text-muted-foreground">
          SecondChance Marketplace
          <br />
          Attn: Privacy Team
          <br />
          123 Market Street
          <br />
          San Francisco, CA 94103
          <br />
          United States
        </address>
        <Link href="/contact">
          <Button>Contact Us</Button>
        </Link>
      </div>
    </div>
  )
}
