"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, CreditCard, Loader2 } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { getCart, checkout, type CartItem } from "@/lib/firebase/cart"

const shippingSchema = z.object({
  fullName: z.string().min(3, { message: "Full name is required" }),
  streetAddress: z.string().min(5, { message: "Street address is required" }),
  city: z.string().min(2, { message: "City is required" }),
  state: z.string().min(2, { message: "State is required" }),
  zipCode: z.string().min(5, { message: "ZIP code is required" }),
  country: z.string().min(2, { message: "Country is required" }),
  phone: z.string().min(10, { message: "Phone number is required" }),
  paymentMethod: z.enum(["credit_card", "paypal", "apple_pay"]),
})

export default function CheckoutPage() {
  const { user } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [processing, setProcessing] = useState(false)

  const form = useForm<z.infer<typeof shippingSchema>>({
    resolver: zodResolver(shippingSchema),
    defaultValues: {
      fullName: "",
      streetAddress: "",
      city: "",
      state: "",
      zipCode: "",
      country: "US",
      phone: "",
      paymentMethod: "credit_card",
    },
  })

  useEffect(() => {
    if (!user) {
      router.push("/auth/login?redirect=/checkout")
      return
    }

    const fetchCart = async () => {
      try {
        const items = await getCart(user.uid)

        if (items.length === 0) {
          toast({
            title: "Empty cart",
            description: "Your cart is empty. Add some items before checkout.",
            variant: "destructive",
          })
          router.push("/products")
          return
        }

        setCartItems(items)
      } catch (error) {
        console.error("Error fetching cart:", error)
        toast({
          title: "Error",
          description: "Failed to load your cart",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchCart()
  }, [user, router, toast])

  const onSubmit = async (data: z.infer<typeof shippingSchema>) => {
    if (!user || cartItems.length === 0) return

    setProcessing(true)
    try {
      // Extract payment method
      const { paymentMethod, ...shippingAddress } = data

      // Process checkout
      const orderId = await checkout(user.uid, shippingAddress, paymentMethod)

      if (!orderId) {
        throw new Error("Checkout failed")
      }

      toast({
        title: "Order placed",
        description: "Your order has been successfully placed!",
      })

      // Redirect to order confirmation page
      router.push(`/orders/${orderId}`)
    } catch (error) {
      console.error("Error during checkout:", error)
      toast({
        title: "Checkout failed",
        description: "There was a problem processing your order. Please try again.",
        variant: "destructive",
      })
    } finally {
      setProcessing(false)
    }
  }

  // Calculate totals
  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = cartItems.length > 0 ? 5.99 : 0
  const tax = subtotal * 0.08
  const total = subtotal + shipping + tax

  if (!user) {
    return null // Redirect handled in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Link href="/cart">
        <Button variant="ghost" className="mb-4 -ml-4 flex items-center gap-1">
          <ArrowLeft className="h-4 w-4" /> Back to Cart
        </Button>
      </Link>

      <h1 className="mb-6 text-3xl font-bold">Checkout</h1>

      {loading ? (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-48" />
              </CardHeader>
              <CardContent className="space-y-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </CardContent>
            </Card>
          </div>
          <div>
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Separator />
                <Skeleton className="h-6 w-full" />
              </CardContent>
              <CardFooter>
                <Skeleton className />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-10 w-full" />
              </CardFooter>
            </Card>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <div className="md:col-span-2">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Shipping Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="streetAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Street Address</FormLabel>
                          <FormControl>
                            <Input placeholder="123 Main St" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl>
                              <Input placeholder="New York" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>State/Province</FormLabel>
                            <FormControl>
                              <Input placeholder="NY" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="zipCode"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>ZIP/Postal Code</FormLabel>
                            <FormControl>
                              <Input placeholder="10001" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select country" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="US">United States</SelectItem>
                                <SelectItem value="CA">Canada</SelectItem>
                                <SelectItem value="UK">United Kingdom</SelectItem>
                                <SelectItem value="AU">Australia</SelectItem>
                                <SelectItem value="DE">Germany</SelectItem>
                                <SelectItem value="FR">France</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="(123) 456-7890" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Payment Method</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <FormField
                      control={form.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <RadioGroup onValueChange={field.onChange} defaultValue={field.value} className="space-y-3">
                              <div className="flex items-center space-x-2 rounded-md border p-3">
                                <RadioGroupItem value="credit_card" id="credit_card" />
                                <label htmlFor="credit_card" className="flex flex-1 cursor-pointer items-center gap-2">
                                  <CreditCard className="h-4 w-4" />
                                  <span>Credit/Debit Card</span>
                                </label>
                              </div>
                              <div className="flex items-center space-x-2 rounded-md border p-3">
                                <RadioGroupItem value="paypal" id="paypal" />
                                <label htmlFor="paypal" className="flex flex-1 cursor-pointer items-center gap-2">
                                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944 3.72a.641.641 0 0 1 .632-.546h6.964c2.075 0 3.76.417 4.741 1.252.473.412.838.95 1.084 1.613.255.683.303 1.435.142 2.3l-.013.076v.743c-.04.267-.1.53-.184.786a5.67 5.67 0 0 1-.42.999 4.411 4.411 0 0 1-.713.945 5.395 5.395 0 0 1-1.066.768 6.333 6.333 0 0 1-1.49.511c-.57.128-1.22.188-1.933.188h-.583c-.534 0-1.054.196-1.445.553-.391.357-.633.844-.675 1.378l-.015.118-.592 3.95-.013.087a.156.156 0 0 1-.156.135z" />
                                    <path d="M19.076 7.51c-.016.107-.026.214-.041.32-.55 2.82-2.506 3.99-5.4 3.99h-1.645c-.316 0-.605.18-.744.464l-1.39 8.878a.38.38 0 0 0 .375.437h2.895c.253 0 .485-.159.566-.4l.025-.08.492-3.126.031-.17a.644.644 0 0 1 .636-.544h.42c2.449 0 4.465-1.072 5.142-4.073.046-.204.085-.399.117-.583.128-.754.091-1.394-.195-1.982-.126-.253-.296-.464-.5-.639z" />
                                  </svg>
                                  <span>PayPal</span>
                                </label>
                              </div>
                              <div className="flex items-center space-x-2 rounded-md border p-3">
                                <RadioGroupItem value="apple_pay" id="apple_pay" />
                                <label htmlFor="apple_pay" className="flex flex-1 cursor-pointer items-center gap-2">
                                  <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M17.72 7.39a3.92 3.92 0 0 0-3.3 1.61 3.45 3.45 0 0 0 1.1 2.6 7.49 7.49 0 0 0-1.19 2.9c-.25 1.06-.14 2.27.33 3.32.59 1.33 1.43 2.62 2.54 3.69-1.41-.19-2.68-.89-3.71-1.92-.87-.87-1.54-1.95-1.95-3.11-.39-1.08-.54-2.24-.45-3.39a5.1 5.1 0 0 1 1.17-2.89 5.22 5.22 0 0 1 2.66-1.77 5.4 5.4 0 0 1 3.12.05 5.32 5.32 0 0 0-1.32-1.09zm-5.77-.21a4.01 4.01 0 0 0-3.34 1.62 3.44 3.44 0 0 0 1.1 2.6 7.49 7.49 0 0 0-1.19 2.9c-.25 1.06-.14 2.27.33 3.32.59 1.33 1.43 2.62 2.54 3.69-1.41-.19-2.68-.89-3.71-1.92-.87-.87-1.54-1.95-1.95-3.11-.39-1.08-.54-2.24-.45-3.39a5.1 5.1 0 0 1 1.17-2.89 5.22 5.22 0 0 1 2.66-1.77 5.4 5.4 0 0 1 3.12.05 5.32 5.32 0 0 0-1.28-1.1z" />
                                  </svg>
                                  <span>Apple Pay</span>
                                </label>
                              </div>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </CardContent>
                </Card>

                <div className="flex justify-end md:hidden">
                  <Button type="submit" className="w-full" disabled={processing}>
                    {processing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                      </>
                    ) : (
                      `Complete Order • $${total.toFixed(2)}`
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </div>

          <div>
            <Card className="sticky top-20">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="max-h-60 overflow-y-auto space-y-3">
                  {cartItems.map((item) => (
                    <div key={item.productId} className="flex gap-3">
                      <div className="h-16 w-16 shrink-0 overflow-hidden rounded-md border">
                        <img
                          src={item.image || "/placeholder.svg?height=64&width=64"}
                          alt={item.title}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="line-clamp-1 font-medium">{item.title}</p>
                        <p className="text-sm text-muted-foreground">
                          Qty: {item.quantity} × ${item.price.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>${shipping.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button
                  type="submit"
                  className="w-full hidden md:flex"
                  disabled={processing}
                  onClick={form.handleSubmit(onSubmit)}
                >
                  {processing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                    </>
                  ) : (
                    `Complete Order • $${total.toFixed(2)}`
                  )}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
