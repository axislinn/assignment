"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/components/ui/use-toast"
import { Send } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { getChats, getMessages, sendMessage, createChat } from "@/lib/firebase/messages"

export default function MessagesPage() {
  const { user } = useAuth()
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const [chats, setChats] = useState<any[]>([])
  const [messages, setMessages] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedChat, setSelectedChat] = useState<string | null>(null)
  const [newMessage, setNewMessage] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Get chat ID or seller ID from URL if provided
  const chatId = searchParams.get("chat")
  const sellerId = searchParams.get("seller")

  useEffect(() => {
    if (!user) {
      router.push("/auth/login")
      return
    }

    const fetchChats = async () => {
      try {
        const userChats = await getChats(user.uid)
        setChats(userChats)

        // If chat ID is provided in URL, select that chat
        if (chatId) {
          setSelectedChat(chatId)
        }
        // If seller ID is provided in URL, select that chat or create a new one
        else if (sellerId) {
          const existingChat = userChats.find(
            (chat) => chat.participants.includes(sellerId) && chat.participants.includes(user.uid),
          )

          if (existingChat) {
            setSelectedChat(existingChat.id)
          } else {
            // Create a new chat with this seller
            try {
              const newChatId = await createChat([user.uid, sellerId])

              // Fetch the seller info
              const newChat = {
                id: newChatId,
                participants: [user.uid, sellerId],
                lastMessage: { text: "No messages yet", timestamp: new Date() },
                otherUser: {
                  id: sellerId,
                  displayName: "Seller",
                  photoURL: null,
                },
              }

              setChats([newChat, ...userChats])
              setSelectedChat(newChatId)
            } catch (error) {
              console.error("Error creating new chat:", error)
              toast({
                title: "Error",
                description: "Failed to create conversation with seller",
                variant: "destructive",
              })
            }
          }
        } else if (userChats.length > 0) {
          // Select first chat by default
          setSelectedChat(userChats[0].id)
        }
      } catch (error) {
        console.error("Error fetching chats:", error)
        toast({
          title: "Error",
          description: "Failed to load your conversations",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchChats()
  }, [user, router, toast, chatId, sellerId])

  useEffect(() => {
    if (selectedChat) {
      const fetchMessages = async () => {
        try {
          const chatMessages = await getMessages(selectedChat)
          setMessages(chatMessages)
        } catch (error) {
          console.error("Error fetching messages:", error)
          toast({
            title: "Error",
            description: "Failed to load messages",
            variant: "destructive",
          })
        }
      }

      fetchMessages()
    } else {
      setMessages([])
    }
  }, [selectedChat, toast])

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newMessage.trim() || !selectedChat || !user) return

    try {
      const message = {
        text: newMessage,
        senderId: user.uid,
        timestamp: new Date(),
      }

      await sendMessage(selectedChat, message)

      // Update local state
      setMessages([...messages, message])
      setNewMessage("")

      // Update last message in chat list
      setChats(
        chats.map((chat) => {
          if (chat.id === selectedChat) {
            return {
              ...chat,
              lastMessage: {
                text: newMessage,
                timestamp: new Date(),
              },
            }
          }
          return chat
        }),
      )
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      })
    }
  }

  if (!user) {
    return null // Redirect handled in useEffect
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 text-3xl font-bold">Messages</h1>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3 lg:grid-cols-4">
        <div className="md:col-span-1">
          <div className="rounded-lg border bg-card shadow-sm">
            <div className="p-4">
              <h2 className="text-lg font-semibold">Conversations</h2>
            </div>
            <Separator />

            {loading ? (
              <div className="space-y-4 p-4">
                {Array.from({ length: 5 }).map((_, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </div>
                ))}
              </div>
            ) : chats.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground">No conversations yet</div>
            ) : (
              <div className="space-y-1 p-2">
                {chats.map((chat) => (
                  <button
                    key={chat.id}
                    className={`flex w-full items-center gap-3 rounded-md p-2 text-left hover:bg-accent ${
                      selectedChat === chat.id ? "bg-accent" : ""
                    }`}
                    onClick={() => setSelectedChat(chat.id)}
                  >
                    <Avatar>
                      <AvatarImage src={chat.otherUser?.photoURL} />
                      <AvatarFallback>{chat.otherUser?.displayName?.charAt(0) || "U"}</AvatarFallback>
                    </Avatar>
                    <div className="overflow-hidden">
                      <p className="font-medium">{chat.otherUser?.displayName || "Unknown User"}</p>
                      <p className="truncate text-sm text-muted-foreground">
                        {chat.lastMessage?.text || "No messages yet"}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="flex flex-col rounded-lg border bg-card shadow-sm md:col-span-2 lg:col-span-3">
          {!selectedChat ? (
            <div className="flex flex-1 flex-col items-center justify-center p-8">
              <h3 className="text-lg font-medium">Select a conversation</h3>
              <p className="text-muted-foreground">Choose a conversation from the list to start messaging</p>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-3 border-b p-4">
                {chats.find((chat) => chat.id === selectedChat)?.otherUser && (
                  <>
                    <Avatar>
                      <AvatarImage src={chats.find((chat) => chat.id === selectedChat)?.otherUser?.photoURL} />
                      <AvatarFallback>
                        {chats.find((chat) => chat.id === selectedChat)?.otherUser?.displayName?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">
                        {chats.find((chat) => chat.id === selectedChat)?.otherUser?.displayName || "Unknown User"}
                      </h3>
                    </div>
                  </>
                )}
              </div>

              <div className="flex-1 overflow-y-auto p-4" style={{ minHeight: "400px" }}>
                {messages.length === 0 ? (
                  <div className="flex h-full items-center justify-center text-muted-foreground">
                    No messages yet. Start the conversation!
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((message, index) => (
                      <div
                        key={index}
                        className={`flex ${message.senderId === user.uid ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[70%] rounded-lg px-4 py-2 ${
                            message.senderId === user.uid ? "bg-primary text-primary-foreground" : "bg-muted"
                          }`}
                        >
                          <p>{message.text}</p>
                          <p
                            className={`text-right text-xs ${
                              message.senderId === user.uid ? "text-primary-foreground/70" : "text-muted-foreground"
                            }`}
                          >
                            {new Date(message.timestamp).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </div>

              <div className="border-t p-4">
                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    className="flex-1"
                  />
                  <Button type="submit" disabled={!newMessage.trim()}>
                    <Send className="h-4 w-4" />
                    <span className="sr-only">Send</span>
                  </Button>
                </form>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
