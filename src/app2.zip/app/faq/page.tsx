import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "FAQ | SecondChance Marketplace",
  description: "Frequently asked questions about SecondChance Marketplace",
}

export default function FAQPage() {
  const faqCategories = [
    {
      id: "general",
      name: "General",
      questions: [
        {
          question: "What is SecondChance Marketplace?",
          answer:
            "SecondChance is an online marketplace where users can buy and sell second-hand items. Our platform connects buyers and sellers directly, creating a sustainable way to give items a second life.",
        },
        {
          question: "How do I create an account?",
          answer:
            "You can create an account by clicking the 'Sign Up' button in the top right corner of the page. You'll need to provide your email address and create a password, or you can sign up using your Google account.",
        },
        {
          question: "Is SecondChance available in my country?",
          answer:
            "Currently, SecondChance is available in the United States, Canada, and the United Kingdom. We're working on expanding to more countries soon!",
        },
        {
          question: "How do I contact customer support?",
          answer:
            "You can reach our customer support team by visiting our Contact page, sending an email to support@secondchance.com, or calling our support line at +1 (234) 567-890 during business hours.",
        },
      ],
    },
    {
      id: "buying",
      name: "Buying",
      questions: [
        {
          question: "How do I search for items?",
          answer:
            "You can search for items using the search bar at the top of the page, browse by category, or use the filters on the Products page to narrow down your search by price, condition, and more.",
        },
        {
          question: "How do I pay for items?",
          answer:
            "SecondChance supports various payment methods including credit/debit cards, PayPal, and other major payment providers. All transactions are processed securely through our platform.",
        },
        {
          question: "Can I negotiate the price with the seller?",
          answer:
            "Yes, you can contact the seller directly through our messaging system to discuss the price or ask any questions about the item before making a purchase.",
        },
        {
          question: "What if the item I receive is not as described?",
          answer:
            "If you receive an item that doesn't match the description, you can contact the seller first to resolve the issue. If that doesn't work, you can open a dispute through our platform, and our team will help mediate the situation.",
        },
      ],
    },
    {
      id: "selling",
      name: "Selling",
      questions: [
        {
          question: "How do I list an item for sale?",
          answer:
            "To list an item, you need to create a seller account. Once approved, you can click on 'Sell' in your dashboard and follow the prompts to add photos, description, price, and shipping details.",
        },
        {
          question: "How much does it cost to sell on SecondChance?",
          answer:
            "Basic listings are free. We charge a 5% commission on successful sales. Featured listings that appear at the top of search results have an additional small fee.",
        },
        {
          question: "How do I get paid for my sales?",
          answer:
            "When a buyer purchases your item, the payment is held securely until the buyer confirms receipt. Once confirmed, the funds (minus our commission) are transferred to your connected bank account or PayPal.",
        },
        {
          question: "How do I ship items to buyers?",
          answer:
            "After a sale, you'll receive the buyer's shipping information. You're responsible for packaging and shipping the item. We recommend using tracked shipping methods for security.",
        },
      ],
    },
    {
      id: "account",
      name: "Account",
      questions: [
        {
          question: "How do I reset my password?",
          answer:
            "You can reset your password by clicking 'Forgot password?' on the login page. We'll send a password reset link to your registered email address.",
        },
        {
          question: "Can I have both a buyer and seller account?",
          answer:
            "Yes, you can upgrade your buyer account to a seller account at any time through your profile settings. This will give you access to all selling features.",
        },
        {
          question: "How do I delete my account?",
          answer:
            "You can request account deletion in your account settings. Note that if you have active listings or ongoing transactions, you'll need to complete or cancel them first.",
        },
        {
          question: "How do I update my profile information?",
          answer:
            "You can update your profile information, including your name, email, and profile picture, in your account settings.",
        },
      ],
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="mb-4 text-4xl font-bold">Frequently Asked Questions</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">
          Find answers to common questions about using SecondChance Marketplace. Can't find what you're looking for?
          Feel free to contact our support team.
        </p>
      </div>

      <Tabs defaultValue="general" className="mb-12">
        <TabsList className="mb-8 flex w-full flex-wrap justify-center gap-2">
          {faqCategories.map((category) => (
            <TabsTrigger key={category.id} value={category.id} className="px-6">
              {category.name}
            </TabsTrigger>
          ))}
        </TabsList>
        {faqCategories.map((category) => (
          <TabsContent key={category.id} value={category.id}>
            <Accordion type="single" collapsible className="w-full">
              {category.questions.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-left font-medium">{faq.question}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </TabsContent>
        ))}
      </Tabs>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Still have questions?</CardTitle>
            <CardDescription>
              Our support team is here to help you with any questions or issues you might have.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/contact">
              <Button className="w-full">Contact Support</Button>
            </Link>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Check our guides</CardTitle>
            <CardDescription>
              We have detailed guides and tutorials to help you make the most of SecondChance.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/help">
              <Button variant="outline" className="w-full">
                View Guides
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
