"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { getCategories } from "@/lib/firebase/categories"

export default function CategoryList() {
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const fetchedCategories = await getCategories()
        setCategories(fetchedCategories)
      } catch (error) {
        console.error("Error fetching categories:", error)
        // Set empty array instead of leaving in loading state
        setCategories([])
      } finally {
        setLoading(false)
      }
    }

    fetchCategories()
  }, [])

  if (loading) {
    return (
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
        {Array.from({ length: 6 }).map((_, index) => (
          <Card key={index} className="overflow-hidden">
            <Skeleton className="aspect-square w-full" />
            <CardContent className="p-4">
              <Skeleton className="h-4 w-20" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  // Fallback categories if none are found in the database
  const fallbackCategories = [
    { id: "electronics", name: "Electronics", icon: "📱" },
    { id: "clothing", name: "Clothing", icon: "👕" },
    { id: "furniture", name: "Furniture", icon: "🪑" },
    { id: "books", name: "Books", icon: "📚" },
    { id: "toys", name: "Toys", icon: "🧸" },
    { id: "sports", name: "Sports", icon: "⚽" },
  ]

  const displayCategories = categories.length > 0 ? categories : fallbackCategories

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
      {displayCategories.map((category) => (
        <Link key={category.id} href={`/categories/${category.id}`}>
          <Card className="overflow-hidden transition-all hover:shadow-md">
            <div className="flex aspect-square items-center justify-center bg-muted/30 text-4xl">
              {category.icon || "🔍"}
            </div>
            <CardContent className="p-4 text-center">
              <h3 className="font-medium">{category.name}</h3>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
