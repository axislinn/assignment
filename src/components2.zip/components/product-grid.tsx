"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-context"
import { getProducts } from "@/lib/firebase/products"
import { toggleWishlist } from "@/lib/firebase/wishlist"
import { useToast } from "@/components/ui/use-toast"

interface ProductGridProps {
  featured?: boolean
  category?: string
  sellerId?: string
  limit?: number
  userId?: string
}

export default function ProductGrid({ featured = false, category, sellerId, limit = 12, userId }: ProductGridProps) {
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()
  const { toast } = useToast()

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const fetchedProducts = await getProducts({
          featured,
          category: category === "all" ? undefined : category,
          sellerId,
          limit,
          userId: userId || user?.uid,
        })
        setProducts(fetchedProducts)
      } catch (error) {
        console.error("Error fetching products:", error)
        // Set empty array instead of leaving in loading state
        setProducts([])
      } finally {
        setLoading(false)
      }
    }

    fetchProducts()
  }, [featured, category, sellerId, limit, userId, user?.uid])

  const handleWishlist = async (productId: string) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to add items to your wishlist",
        variant: "destructive",
      })
      return
    }

    try {
      await toggleWishlist(user.uid, productId)

      // Update local state to reflect the change
      setProducts(
        products.map((product) => {
          if (product.id === productId) {
            return {
              ...product,
              isWishlisted: !product.isWishlisted,
            }
          }
          return product
        }),
      )

      toast({
        title: "Success",
        description: "Wishlist updated successfully",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update wishlist",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
        {Array.from({ length: limit }).map((_, index) => (
          <Card key={index} className="overflow-hidden">
            <Skeleton className="aspect-square w-full" />
            <CardContent className="p-4">
              <Skeleton className="mb-2 h-4 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </CardContent>
            <CardFooter className="p-4 pt-0">
              <Skeleton className="h-4 w-1/4" />
            </CardFooter>
          </Card>
        ))}
      </div>
    )
  }

  if (products.length === 0) {
    return <p className="text-center text-muted-foreground">No products found.</p>
  }

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
      {products.map((product) => (
        <Card key={product.id} className="overflow-hidden transition-all hover:shadow-md">
          <div className="relative">
            <Link href={`/products/${product.id}`}>
              <div className="aspect-square overflow-hidden">
                <img
                  src={product.images?.[0] || "/placeholder.svg?height=300&width=300"}
                  alt={product.title || "Product"}
                  className="h-full w-full object-cover transition-transform hover:scale-105"
                />
              </div>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-2 rounded-full bg-background/80 backdrop-blur-sm"
              onClick={() => handleWishlist(product.id)}
            >
              <Heart className={`h-5 w-5 ${product.isWishlisted ? "fill-red-500 text-red-500" : ""}`} />
            </Button>
            {product.featured && <Badge className="absolute left-2 top-2">Featured</Badge>}
          </div>
          <CardContent className="p-4">
            <Link href={`/products/${product.id}`}>
              <h3 className="line-clamp-1 text-lg font-medium hover:underline">
                {product.title || "Untitled Product"}
              </h3>
            </Link>
            <p className="text-lg font-bold text-primary">${(product.price || 0).toFixed(2)}</p>
            <p className="line-clamp-2 text-sm text-muted-foreground">
              {product.description || "No description available"}
            </p>
          </CardContent>
          <CardFooter className="flex items-center justify-between p-4 pt-0">
            <div className="flex items-center text-sm text-muted-foreground">
              <span>{product.location || "Unknown location"}</span>
            </div>
            <Badge variant="outline" className="capitalize">
              {product.condition || "Used"}
            </Badge>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
