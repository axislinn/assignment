// This file is deprecated. Please use @/lib/firebase/config.ts instead
export { auth, db } from '@/lib/firebase/config'
